namespace $safeprojectname$.ModelDescriptions
{
    public class SimpleTypeModelDescription : ModelDescription
    {
    }
}
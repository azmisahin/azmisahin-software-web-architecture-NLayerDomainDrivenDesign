﻿CREATE TABLE [dbo].[Setup]
(
	[Id] INT NOT NULL PRIMARY KEY, 
    [Name] NVARCHAR(50) NULL, 
    [Value] NVARCHAR(50) NULL	
)

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Optimization;

namespace com.domain
{
    /// <summary>
    /// Css And Java Script Performas Tool
    /// </summary>
    public class BundleConfig
    {
        /// <summary>
        /// Register Bundless
        /// </summary>
        /// <param name="bundles"></param>
        public static void RegisterBundles(BundleCollection bundles)
        {
        }
    }
}
